﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Unique.EcommGroceryStore.Core.Common
{
    public class SessionManager
    {
        public const string UserId = "UserId";
        public const string CAPTCHA = "Captcha";
        public const string SESSION_SUCCESSFUL_REGISTRATION = "SuccessfullRegistration";
        public const string UserName = "UserName";
        public const string Role = "Role";
        public const string MobileNumbers = "MobileNumbers";
    }
}
