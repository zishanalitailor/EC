﻿using System.Web.UI;

namespace EcommGroceryStore.Account
{
    public partial class ResetPasswordConfirmation : Page
    {
    }
}