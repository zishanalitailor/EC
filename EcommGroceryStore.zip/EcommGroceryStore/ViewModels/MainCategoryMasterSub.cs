﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace EcommGroceryStore.ViewModels
{
    public class MainCategoryMasterSub
    {
        public int MainCategoryId { get; set; }
        public string MainCategoryName { get; set; }
    }
}