﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace EcommGroceryStore.ViewModels
{
    public class SubCategoryMasterSub
    {
        public int SubCategoryId { get; set; }
        public string SubCategoryName { get; set; }
    }
}